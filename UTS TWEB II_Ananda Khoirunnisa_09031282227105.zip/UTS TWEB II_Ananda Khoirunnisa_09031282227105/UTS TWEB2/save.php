<?php
require 'connection.php';

if(isset($_POST["submit"])){
    $name = $_POST["name"];
    $nim = $_POST["nim"];
    $major = $_POST["major"];
    $age = $_POST["age"];
    $city = $_POST["city"];
    $gender = $_POST["gender"];

    $query = "INSERT INTO tb_data (name, age, city, gender, nim, major) VALUES ('$name', '$age', '$city', '$gender', '$nim', '$major')";
    $hasil = mysqli_query($conn, $query);

    if ($hasil) {
        header("Location: show.php");
        exit();
    } else {
        echo "Penyimpanan Gagal !!";
    }
}
?>
