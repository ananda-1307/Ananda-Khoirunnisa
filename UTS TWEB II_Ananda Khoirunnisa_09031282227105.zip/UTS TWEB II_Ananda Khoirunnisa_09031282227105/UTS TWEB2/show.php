<table border="1">
    <thead>
        <th>Name</th><th>NIM</th><th>Major</th><th>Age</th><th>City</th><th>Gender</th><th>Action</th>
    </thead>
    <tbody>
        <?php
        require_once("connection.php");

        $query = "SELECT * FROM tb_data";
        $hasil = mysqli_query($conn, $query);

        if (!$hasil)
            die("Permintaan Gagal !! ");

        while ($tb_data = mysqli_fetch_array($hasil)) {
        ?>
            <tr>
                <td><?php echo $tb_data['name']; ?></td>
                <td><?php echo $tb_data['nim']; ?></td>
                <td><?php echo $tb_data['major']; ?></td>
                <td><?php echo $tb_data['age']; ?></td>
                <td><?php echo $tb_data['city']; ?></td>
                <td><?php echo $tb_data['gender']; ?></td>
                <td>
                    <a href="edit_form.php?id=<?php echo $tb_data['id']; ?>">Edit</a> | 
                    <a href="delete.php?id=<?php echo $tb_data['id']; ?>">Delete</a>
                </td>
            </tr>
        <?php
        }
        ?>
    </tbody>
</table>
