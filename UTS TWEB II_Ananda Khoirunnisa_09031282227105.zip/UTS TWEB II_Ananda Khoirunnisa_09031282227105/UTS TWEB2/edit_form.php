<?php
include_once('connection.php');

// Periksa apakah ada parameter id dalam URL
if(isset($_GET['id'])) {
    // Membersihkan dan memvalidasi ID
    $id = intval($_GET['id']);

    // Query untuk mengambil data mahasiswa berdasarkan id
    $query = "SELECT * FROM tb_data WHERE id='$id'";
    $hasil = mysqli_query($conn, $query);

    // Periksa apakah data ditemukan
    if(mysqli_num_rows($hasil) > 0) {
        $tb_data = mysqli_fetch_assoc($hasil);
?>
<html>
<head>
    <title>Form Ubah Data Mahasiswa</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            width: 400px;
            margin: 0 auto;
        }
        h2 {
            text-align: center;
        }
        form {
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 5px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input[type="text"],
        input[type="number"],
        select {
            width: calc(100% - 10px);
            padding: 5px;
            margin-bottom: 10px;
        }
        input[type="radio"] {
            margin-right: 5px;
        }
        input[type="submit"],
        input[type="reset"] {
            padding: 8px 15px;
            background-color: #4CAF50;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover,
        input[type="reset"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Form Ubah Data Mahasiswa</h2>
        <form action="edit.php" method="POST">
            <input type="hidden" name="id" value="<?php echo $id; ?>" />

            <label for="name">Name:</label>
            <input type="text" name="name" value="<?php echo $tb_data['name']; ?>">

            <label for="nim">NIM:</label>
            <input type="text" name="nim" value="<?php echo $tb_data['nim']; ?>">

            <label for="major">Major:</label>
            <input type="text" name="major" value="<?php echo $tb_data['major']; ?>">

            <label for="age">Age:</label>
            <input type="number" name="age" value="<?php echo $tb_data['age']; ?>">

            <label for="city">City:</label>
            <select name="city">
                <?php
                    $cities = array("Jakarta", "Palembang", "Medan", "Padang", "Bandung", "Bali", "Lampung", "Banda Aceh", "Denpasar", "Bandar Lampung", "Bangka", "Pangkal Pinang", "Banjarmasin", "Palangka Raya", "Pontianak", "Gorontalo", "Makassar", "Manado", "Palu", "Kendari", "Ambon", "Ternate", "Jayapura", "Mamuju", "Mataram", "Kupang", "Samarinda", "Tanjung Pinang", "Palopo", "Tanjung Selor", "Tanjung Redeb", "Sorong", "Ternate", "Dumai", "Kota Sorong");
                    foreach ($cities as $city) {
                        echo "<option value='$city'";
                        if ($tb_data['city'] == $city) {
                            echo " selected";
                        }
                        echo ">$city</option>";
                    }
                ?>
            </select>

            <label for="gender">Gender:</label>
            <input type="radio" name="gender" value="Male" <?php if ($tb_data['gender'] == "Male") echo "checked"; ?>> Male
            <input type="radio" name="gender" value="Female" <?php if ($tb_data['gender'] == "Female") echo "checked"; ?>> Female

            <div style="margin-top: 10px;">
                <input type="submit" value="Submit" name="submit">
                <input type="reset" value="Reset">
            </div>
        </form>
    </div>
</body>
</html>
<?php
    } else {
        echo "Data dengan ID tersebut tidak ditemukan!";
    }
} else {
    echo "ID tidak diberikan!";
}
?>
