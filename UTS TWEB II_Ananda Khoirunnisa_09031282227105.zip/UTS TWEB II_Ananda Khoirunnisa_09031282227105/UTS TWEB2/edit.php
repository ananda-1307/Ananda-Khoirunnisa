<?php
require 'connection.php';

if(isset($_POST["submit"])) {
    // Ambil nilai dari form
    $id = $_POST["id"];
    $name = $_POST["name"];
    $nim = $_POST["nim"];
    $major = $_POST["major"];
    $age = $_POST["age"];
    $city = $_POST["city"];
    $gender = $_POST["gender"];

    // Query untuk memperbarui data dalam tabel
    $query = "UPDATE tb_data SET name='$name', age='$age', city='$city', gender='$gender', nim='$nim', major='$major' WHERE id='$id'";

    // Eksekusi query
    $hasil = mysqli_query($conn, $query);

    if ($hasil) {
        // Jika pembaruan berhasil, alihkan kembali ke halaman show.php dengan menyertakan ID yang diperbarui
        header("Location: show.php?id=$id");
        exit();
    } else {
        echo "Gagal memperbarui data!";
    }
} else {
    // Jika tidak ada data yang dikirimkan melalui POST, arahkan ke halaman show.php
    header("Location: show.php");
    exit();
}
?>
