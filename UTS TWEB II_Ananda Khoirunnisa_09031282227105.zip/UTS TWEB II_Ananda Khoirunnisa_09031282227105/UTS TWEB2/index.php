<?php
require 'connection.php';

function insertData($name, $age, $city, $gender, $nim, $major) {
    global $conn;
    $query = "INSERT INTO tb_data (name, age, city, gender, nim, major) VALUES ('$name', '$age', '$city', '$gender', '$nim', '$major')";
    return mysqli_query($conn, $query);
}

if(isset($_POST["submit"])){
  $name = $_POST["name"];
  $nim = $_POST["nim"];
  $major = $_POST["major"];
  $age = $_POST["age"];
  $city = $_POST["city"];
  $gender = $_POST["gender"];

  if(insertData($name, $age, $city, $gender, $nim, $major)) {
    echo "<script> alert('Data Inserted Successfully'); </script>";
  } else {
    echo "<script> alert('Failed to insert data'); </script>";
  }
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <title>DATA ASAL KOTA MAHASISWA</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
      margin: 0;
      padding: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }
    form {
      background-color: #fff;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    label {
      display: block;
      margin-bottom: 5px;
    }
    input[type="text"],
    input[type="number"],
    select {
      width: calc(100% - 12px);
      padding: 8px;
      margin-bottom: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }
    select {
      cursor: pointer;
    }
    input[type="radio"] {
      margin-right: 5px;
    }
    button[type="submit"] {
      padding: 10px 20px;
      background-color: #4CAF50;
      border: none;
      color: white;
      border-radius: 5px;
      cursor: pointer;
    }
    button[type="submit"]:hover {
      background-color: #45a049;
    }
  </style>
</head>
<body>
  <form action="" method="post" autocomplete="off">
    <h2 style="text-align: center;">DATA ASAL KOTA MAHASISWA</h2>
    <label for="name">Name:</label>
    <input type="text" name="name" required>
    <label for="nim">NIM:</label>
    <input type="text" name="nim" required>
    <label for="major">Major:</label>
    <input type="text" name="major" required>
    <label for="age">Age:</label>
    <input type="number" name="age" required>
    <label for="city">City:</label>
    <select name="city" required>
      <option value="" selected hidden>Select City</option>
      <?php
        $cities = array("Jakarta", "Palembang", "Medan", "Padang", "Bandung", "Bali", "Lampung", "Banda Aceh", "Denpasar", "Bandar Lampung", "Bangka", "Pangkal Pinang", "Banjarmasin", "Palangka Raya", "Pontianak", "Gorontalo", "Makassar", "Manado", "Palu", "Kendari", "Ambon", "Ternate", "Jayapura", "Mamuju", "Mataram", "Kupang", "Samarinda", "Tanjung Pinang", "Palopo", "Tanjung Selor", "Tanjung Redeb", "Sorong", "Ternate", "Dumai", "Kota Sorong");
        foreach ($cities as $city) {
          echo "<option value='$city'>$city</option>";
        }
      ?>
    </select>
    <label for="gender">Gender:</label>
    <input type="radio" name="gender" value="Male" required> Male
    <input type="radio" name="gender" value="Female"> Female
    <br><br>
    <button type="submit" name="submit">Submit</button>
  </form>
</body>
</html>
