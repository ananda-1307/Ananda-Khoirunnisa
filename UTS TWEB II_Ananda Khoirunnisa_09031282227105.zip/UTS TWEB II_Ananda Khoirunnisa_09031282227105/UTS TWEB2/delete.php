<?php
require 'connection.php';

if(isset($_GET["id"])) {
    $id = $_GET["id"];
    
    // Query untuk menghapus data dengan ID yang diberikan
    $query = "DELETE FROM tb_data WHERE id='$id'";
    
    // Eksekusi query
    $hasil = mysqli_query($conn, $query);

    if ($hasil) {
        // Jika penghapusan berhasil, alihkan kembali ke halaman show.php
        header("Location: show.php");
        exit();
    } else {
        echo "Gagal menghapus data!";
    }
} else {
    echo "ID tidak diberikan!";
}
?>
