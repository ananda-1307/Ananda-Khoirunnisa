<?php
//connection
$db = mysqli_connect("localhost","root","","akademik");


function query($query){
    global $db;
    $result = mysqli_query($db, $query);
    $contents= [];
    while($content=mysqli_fetch_assoc($result)){
        $contents[]=$content;
    }
    return $contents;
}



?>