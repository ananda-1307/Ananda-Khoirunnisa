<?php
//connection
require 'function.php';
$mahasiswa = query("SELECT * FROM mahasiswa")
    ?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <title>Tabel Mahasiswa</title>
</head>

<body>
    
    <div class="container">
    <h2 class="title">DATA MAHASISWA</h2>
    <a href="tambah.php">Tambah Data Mahasiswa</a>
    <br>
        <table class="table table-striped table-hover" border="1" cellpadding="10" cellspacing="0">
            <thead class="table-dark">
                <tr>
                    <th>No</th>
                    <th>Aksi</th>
                    <th>Nama</th>
                    <th>NIM</th>
                </tr>
            </thead>

            <?php $i = 1 ?>
            <?php foreach ($mahasiswa as $content): ?>

                <tbody class="table-light">
                    <tr>
                        <td>
                            <?= $i; ?>
                        </td>
                        <td>
                            <a href="">Edit</a> |
                            <a href="">Delete</a>
                        </td>
                        <td>
                            <?= $content["nama"]; ?>
                        </td>
                        <td>
                            <?= $content["nim"]; ?>
                        </td>
                    </tr>
                </tbody>

                <?php $i++ ?>
            <?php endforeach; ?>

        </table>

    </div>

    <!-- Script -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
        integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.min.js"
        integrity="sha384-heAjqF+bCxXpCWLa6Zhcp4fu20XoNIA98ecBC1YkdXhszjoejr5y9Q77hIrv8R9i"
        crossorigin="anonymous"></script>
</body>

</html>