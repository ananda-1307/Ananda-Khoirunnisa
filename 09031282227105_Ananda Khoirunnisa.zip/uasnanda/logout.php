<?php
setcookie("cookie_username");
setcookie("cookie_pass");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout</title>
    <style>
        body {
            background-color: #f5f5f5;
            font-family: Arial, sans-serif;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .container h1 {
            color: #d9534f;
            margin-bottom: 10px;
        }
        .container p {
            color: #5a5a5a;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Logout Successful!</h1>
        <p>Bila anda ingin mengakses data</p>
        <p>Silakan melakukan login kembali</p>
    </div>
</body>
</html>

