<?php
function password_valid($username, $pass)
{
    if (($username == "ananda1307") && ($pass == "nanda1307"))
        return TRUE;
}
?>
