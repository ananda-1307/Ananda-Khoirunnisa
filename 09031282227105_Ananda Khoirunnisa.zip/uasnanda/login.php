<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
      body {
        background: url('./bg.jpeg') no-repeat center center fixed; 
        background-size: cover;
        color: #333;
      }

      .form-signin {
        background-color: rgba(255, 255, 255, 0.9);
        padding: 2rem;
        border-radius: 1rem;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        max-width: 320px;
        width: 100%;
      }

      .form-signin h1,
      .form-signin label {
        color: #333;
      }

      .form-floating {
        margin-bottom: 1rem;
      }

      .form-control {
        background-color: rgba(255, 255, 255, 0.8);
        border: 1px solid #ccc;
        color: #333;
      }

      .form-control:focus {
        background-color: rgba(255, 255, 255, 0.9);
        color: #333;
      }

      .form-check-input:checked {
        background-color: #ff0000;
        border-color: #ff0000;
      }

      .btn {
        background-color: #ff0000;
        border: none;
        color: #fff;
      }

      .btn:hover {
        background-color: #cc0000;
      }

      .text-body-secondary {
        color: #666;
      }
    </style>
  </head>
  <body class="d-flex align-items-center py-5">
    <main class="form-signin m-auto">
      <form action="set_cookie.php" method="POST">

      <form>
      <img class="mb-4 mx-auto d-block" src="./logo himsi.png" alt="" width="72" height="57">
        <h1 class="h3 mb-3 fw-normal text-center">Please Login</h1>

        <div class="form-floating">
          <input type="username" class="form-control" id="username" placeholder="Username" name="username">
          <label for="username">Username</label>
        </div>

        <div class="form-floating">
          <input type="email" class="form-control" id="floatingInput" placeholder="name@example.com">
          <label for="floating">Email address</label>
        </div>

        <div class="form-floating">
          <input type="password" class="form-control" id="floatingPassword" placeholder="Password" name="pass">
          <label for="floatingPassword">Password</label>
        </div>

        <div class="form-check text-start my-3">
          <input class="form-check-input" type="checkbox" value="remember-me" id="flexCheckDefault">
          <label class="form-check-label" for="flexCheckDefault">
            Remember me
          </label>
        </div>

        <button class="btn w-100 py-2" type="submit">Login</button>
      </form>
      </form>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>
