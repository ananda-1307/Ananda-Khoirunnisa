<?php
$username = $_POST['username'];
$pass = $_POST['pass'];

setcookie('cookie_username', $username);
setcookie('cookie_pass', $pass);

header("Location: inputdata.php");
?>
